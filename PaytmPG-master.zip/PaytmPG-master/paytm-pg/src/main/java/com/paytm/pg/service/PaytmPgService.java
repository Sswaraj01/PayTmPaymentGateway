package com.paytm.pg.service;

import javax.servlet.http.HttpServletRequest;

import org.springframework.web.servlet.ModelAndView;

public interface PaytmPgService {
	
	ModelAndView redirectToPg(String txnAmount) throws Exception;

	String pgResponse(HttpServletRequest request) throws Exception;

	String verifyTxn(String orderId) throws Exception;
		
	

}
