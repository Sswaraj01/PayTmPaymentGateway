package com.paytm.pg.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.paytm.pg.constant.PaytmPgConstant;

@Entity
@Table(name=PaytmPgConstant.PAYMENT_MASTER)
public class PaymentDetailsEntity {

	@Column(name=PaytmPgConstant.BANKNAME,columnDefinition =PaytmPgConstant.VARCHAR50)
	private String bankName;
	@Column(name=PaytmPgConstant.BANKTXNID,columnDefinition =PaytmPgConstant.VARCHAR50)
	private String bankTxnId;
	@Column(name=PaytmPgConstant.CHECKSUMHASH,columnDefinition =PaytmPgConstant.VARCHAR500)
	private String checksumhash;
	@Column(name=PaytmPgConstant.CURRENCY,columnDefinition =PaytmPgConstant.VARCHAR10)
	private String currency;
	@Column(name=PaytmPgConstant.GATEWAYNAME,columnDefinition =PaytmPgConstant.VARCHAR10)
	private String gatewayName;
	@Column(name=PaytmPgConstant.MID,columnDefinition =PaytmPgConstant.VARCHAR50)
	private String mid;
	@Id
	@Column(name=PaytmPgConstant.ORDERID,columnDefinition =PaytmPgConstant.VARCHAR50, nullable =PaytmPgConstant.FALSE)
	private String orderId;
	@Column(name=PaytmPgConstant.PAYMENTMODE,columnDefinition =PaytmPgConstant.VARCHAR10)
	private String paymentMode;
	@Column(name=PaytmPgConstant.RESPCODE,columnDefinition =PaytmPgConstant.VARCHAR10)
	private String respCode;
	@Column(name=PaytmPgConstant.RESPMSG,columnDefinition =PaytmPgConstant.VARCHAR256)
	private String respMsg;
	@Column(name=PaytmPgConstant.STATUS,columnDefinition =PaytmPgConstant.VARCHAR256)
	private String status;
	@Column(name=PaytmPgConstant.TXNAMOUNT,columnDefinition =PaytmPgConstant.VARCHAR10)
	private String txnAmount;
	@Column(name=PaytmPgConstant.TXNDATE)
	private Date txnDate;
	@Column(name=PaytmPgConstant.TXNID,columnDefinition =PaytmPgConstant.VARCHAR256)
	private String txnId;
	@Column(name=PaytmPgConstant.MOBILE_NO,columnDefinition =PaytmPgConstant.VARCHAR20)
	private String mobileNo;
	@Column(name=PaytmPgConstant.EMAIL,columnDefinition =PaytmPgConstant.VARCHAR50)
	private String email;
	@Column(name=PaytmPgConstant.CUST_ID,columnDefinition =PaytmPgConstant.VARCHAR20)
	private String custId;
	public PaymentDetailsEntity(String bankName, String bankTxnId, String checksumhash, String currency,
			String gatewayName, String mid, String orderId, String paymentMode, String respCode, String respMsg,
			String status, String txnAmount, Date txnDate, String txnId, String mobileNo, String email, String custId) {
		super();
		this.bankName = bankName;
		this.bankTxnId = bankTxnId;
		this.checksumhash = checksumhash;
		this.currency = currency;
		this.gatewayName = gatewayName;
		this.mid = mid;
		this.orderId = orderId;
		this.paymentMode = paymentMode;
		this.respCode = respCode;
		this.respMsg = respMsg;
		this.status = status;
		this.txnAmount = txnAmount;
		this.txnDate = txnDate;
		this.txnId = txnId;
		this.mobileNo = mobileNo;
		this.email = email;
		this.custId = custId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCustId() {
		return custId;
	}
	public void setCustId(String custId) {
		this.custId = custId;
	}
	public PaymentDetailsEntity() {
		super();
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	public String getBankTxnId() {
		return bankTxnId;
	}
	public void setBankTxnId(String bankTxnId) {
		this.bankTxnId = bankTxnId;
	}
	public String getChecksumhash() {
		return checksumhash;
	}
	public void setChecksumhash(String checksumhash) {
		this.checksumhash = checksumhash;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getGatewayName() {
		return gatewayName;
	}
	public void setGatewayName(String gatewayName) {
		this.gatewayName = gatewayName;
	}
	public String getMid() {
		return mid;
	}
	public void setMid(String mid) {
		this.mid = mid;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getPaymentMode() {
		return paymentMode;
	}
	public void setPaymentMode(String paymentMode) {
		this.paymentMode = paymentMode;
	}
	public String getRespCode() {
		return respCode;
	}
	public void setRespCode(String respCode) {
		this.respCode = respCode;
	}
	public String getRespMsg() {
		return respMsg;
	}
	public void setRespMsg(String respMsg) {
		this.respMsg = respMsg;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getTxnAmount() {
		return txnAmount;
	}
	public void setTxnAmount(String txnAmount) {
		this.txnAmount = txnAmount;
	}
	public Date getTxnDate() {
		return txnDate;
	}
	public void setTxnDate(Date txnDate) {
		this.txnDate = txnDate;
	}
	public String getTxnId() {
		return txnId;
	}
	public void setTxnId(String txnId) {
		this.txnId = txnId;
	}
	


}
