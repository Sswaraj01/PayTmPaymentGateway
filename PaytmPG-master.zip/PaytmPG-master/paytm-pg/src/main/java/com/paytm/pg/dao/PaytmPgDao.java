package com.paytm.pg.dao;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paytm.pg.model.PaymentDetailsEntity;
import com.paytm.pg.repository.PaytmPgRepository;

@Component
public class PaytmPgDao {
	
	@Autowired
	private PaytmPgRepository paytmPgRepo;
	
	public void savePaymentDtls(PaymentDetailsEntity pgEntity){
		paytmPgRepo.save(pgEntity);
	}

	public void updatePaymentDtls(PaymentDetailsEntity pgEntity) {
		paytmPgRepo.updatePaymentDtls(pgEntity);
	}
	

}
