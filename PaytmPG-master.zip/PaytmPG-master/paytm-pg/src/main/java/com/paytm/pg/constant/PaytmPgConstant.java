package com.paytm.pg.constant;

public class PaytmPgConstant {
	public static final String PAYMENT_MASTER="PAYMENT_MASTER";
	public static final String BANKNAME = "BANKNAME";
	public static final String BANKTXNID = "BANKTXNID";
	public static final String CHECKSUMHASH = "CHECKSUMHASH";
	public static final String CURRENCY = "CURRENCY";
	public static final String GATEWAYNAME = "GATEWAYNAME";
	public static final String MID = "MID";
	public static final String ORDERID = "ORDERID";
	public static final String PAYMENTMODE = "PAYMENTMODE";
	public static final String RESPCODE = "RESPCODE";
	public static final String RESPMSG = "RESPMSG";
	public static final String STATUS = "STATUS";
	public static final String TXNAMOUNT = "TXNAMOUNT";
	public static final String TXNDATE = "TXNDATE";
	public static final String TXNID = "TXNID";
	public static final String MOBILE_NO = "MOBILE_NO";
	public static final String EMAIL = "EMAIL";
	public static final String CUST_ID = "CUST_ID";
	public static final String VARCHAR10 = "varchar(10)";
	public static final String VARCHAR20 = "varchar(20)";
	public static final String VARCHAR50 = "varchar(50)";
	public static final String VARCHAR500 = "varchar(512)";
	public static final String VARCHAR256 = "varchar(256)";
	public static final boolean FALSE = false;
	public static final String UPDATE_PAYMENT_SQL = "UPDATE PaymentDetailsEntity p SET p.bankName = :#{#pgEntity.bankName},p.bankTxnId = :#{#pgEntity.bankTxnId},"
			+ "p.currency= :#{#pgEntity.currency},p.gatewayName = :#{#pgEntity.gatewayName},p.paymentMode = :#{#pgEntity.paymentMode},"
			+ "p.respCode = :#{#pgEntity.respCode},p.respMsg = :#{#pgEntity.respMsg},p.status = :#{#pgEntity.status},"
			+ "p.txnDate = :#{#pgEntity.txnDate},p.txnId = :#{#pgEntity.txnId} "
			+ "WHERE p.orderId = :#{#pgEntity.orderId}";
}
