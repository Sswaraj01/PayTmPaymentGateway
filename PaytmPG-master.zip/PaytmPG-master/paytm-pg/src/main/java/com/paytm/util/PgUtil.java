package com.paytm.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;

import com.paytm.pg.bean.PaytmDetails;
import com.paytm.pg.merchant.CheckSumServiceHelper;
import com.paytm.pg.model.PaymentDetailsEntity;

public class PgUtil {

	/*@Autowired
	private PaytmDetails paytmDetails;*/
	
	public PaymentDetailsEntity createEntity(TreeMap<String, String> parameters) throws ParseException {
		PaymentDetailsEntity pgEntity=new PaymentDetailsEntity();
		pgEntity.setBankName(parameters.get("BANKNAME"));
		pgEntity.setBankTxnId(parameters.get("BANKTXNID"));
		pgEntity.setChecksumhash(parameters.get("CHECKSUMHASH"));
		pgEntity.setCurrency(parameters.get("CURRENCY"));
		pgEntity.setCustId(parameters.get("CUST_ID"));
		pgEntity.setEmail(parameters.get("EMAIL"));
		pgEntity.setGatewayName(parameters.get("GATEWAYNAME"));
		pgEntity.setMid(parameters.get("MID"));
		pgEntity.setMobileNo(parameters.get("MOBILE_NO"));
		pgEntity.setOrderId((parameters.get("ORDER_ID")!=null)?parameters.get("ORDER_ID"):parameters.get("ORDERID"));
		pgEntity.setPaymentMode(parameters.get("PAYMENTMODE"));
		pgEntity.setRespCode(parameters.get("RESPCODE"));
		pgEntity.setRespMsg(parameters.get("RESPMSG"));
		pgEntity.setStatus(parameters.get("STATUS"));
		pgEntity.setTxnAmount(parameters.get("TXN_AMOUNT"));
		pgEntity.setTxnDate(getDate(parameters.get("TXNDATE")));//2019-02-15 11:16:29.0,
		pgEntity.setTxnId(parameters.get("TXNID"));
		return pgEntity;
	}
	
	private static Date getDate(String dateStr) throws ParseException{
		Date date;
		if(dateStr!=null){
		date=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.s").parse(dateStr);
		}else{
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.s");  
		    Date date1 = new Date();
		    String datestr1=formatter.format(date1);
		    date=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.s").parse(datestr1);
		}
		return date;
	}
	
	public String createOrderId() {
		LocalDateTime now = LocalDateTime.now();
		String orderId="OD"+String.valueOf(now.getYear())+String.valueOf(now.getMonthValue())+String.valueOf(now.getDayOfMonth())
		+String.valueOf(now.getHour())+String.valueOf(now.getMinute())+String.valueOf(now.getSecond())+String.valueOf(now.getNano()).substring(0,2);
		return orderId;
	}
	public String getCustomerId() {
		LocalDateTime now = LocalDateTime.now();
		String custId=String.valueOf(now.getYear())+String.valueOf(now.getMonthValue())+String.valueOf(now.getDayOfMonth())
		+String.valueOf(now.getHour())+String.valueOf(now.getMinute())+String.valueOf(now.getSecond())+String.valueOf(now.getNano()).substring(0,2);
		return custId;
	}
	
	public  String getCheckSum(TreeMap<String, String> parameters,String merchantKey) throws Exception {
		return CheckSumServiceHelper.
				getCheckSumServiceHelper().
				genrateCheckSum(merchantKey, parameters);
	}
	
	public boolean validateCheckSum(TreeMap<String, String> parameters, String paytmChecksum,String merchantKey) throws Exception {
		return CheckSumServiceHelper.
				getCheckSumServiceHelper().
				verifycheckSum(merchantKey,parameters,paytmChecksum);
	}
}
