package com.paytm.pg.repository;



import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.paytm.pg.constant.PaytmPgConstant;
import com.paytm.pg.model.PaymentDetailsEntity;
@Repository
public interface PaytmPgRepository extends JpaRepository<PaymentDetailsEntity,String>{
	
	
	@Modifying
	@Query(PaytmPgConstant.UPDATE_PAYMENT_SQL)
	void updatePaymentDtls(@Param(value = "pgEntity") PaymentDetailsEntity pgEntity);
	
}
