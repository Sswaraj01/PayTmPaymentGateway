package com.paytm.pg.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.paytm.pg.service.PaytmPgService;



@Controller
public class paytmPgController {
	
	
	@Autowired
	private PaytmPgService paytmPgService;
		
	@RequestMapping(value="/pgredirect")
	public ModelAndView getRedirect(@RequestParam(name="TXN_AMOUNT") String transactionAmount) throws Exception {
		return paytmPgService.redirectToPg(transactionAmount);
	}

	@ResponseBody
	@RequestMapping(value="/pgresponse")
	public String getResponseRedirect(HttpServletRequest request) throws Exception {
		
		return paytmPgService.pgResponse(request);
	}
	@ResponseBody
	@RequestMapping(value="/")
	public String getHello(){
		return "Hello";
	}
	@ResponseBody
	@RequestMapping(value="/verifytxn")
	public String verifyTxn(@RequestParam(name="ORDER_ID") String orderId) throws Exception {
		
		return paytmPgService.verifyTxn(orderId);
	}
	

}
