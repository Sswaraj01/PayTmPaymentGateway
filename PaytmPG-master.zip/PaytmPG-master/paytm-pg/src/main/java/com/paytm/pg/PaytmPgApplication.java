package com.paytm.pg;

import java.security.KeyManagementException;
import java.security.NoSuchAlgorithmException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.paytm.util.SSLUtil;

@SpringBootApplication
public class PaytmPgApplication {

	public static void main(String[] args) throws KeyManagementException, NoSuchAlgorithmException {
		SSLUtil.turnOffSslChecking();
		SpringApplication.run(PaytmPgApplication.class, args);
	}

}

