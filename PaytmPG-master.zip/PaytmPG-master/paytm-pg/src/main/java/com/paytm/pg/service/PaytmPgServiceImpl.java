package com.paytm.pg.service;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.Proxy.Type;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.configurationprocessor.json.JSONObject;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.ModelAndView;

import com.paytm.pg.bean.PaytmDetails;
import com.paytm.pg.dao.PaytmPgDao;
import com.paytm.pg.merchant.CheckSumServiceHelper;
import com.paytm.pg.model.PaymentDetailsEntity;
import com.paytm.util.PgUtil;



@Service
public class PaytmPgServiceImpl implements PaytmPgService {
	
	@Autowired
	private PaytmDetails paytmDetails;
	
	@Autowired
	private PaytmPgDao pgDao;
	
	private PgUtil  pgutil=new PgUtil();

	@Override
	public ModelAndView redirectToPg(String transactionAmount) throws Exception {
		ModelAndView modelAndView = new ModelAndView("redirect:"+paytmDetails.getPaytmUrl());
		TreeMap<String, String> parameters = new TreeMap<>();
		getParameters(transactionAmount, parameters);
		modelAndView.addAllObjects(parameters);
		pgDao.savePaymentDtls(pgutil.createEntity(parameters));
		return modelAndView;
	}





	private void getParameters(String transactionAmount, TreeMap<String, String> parameters) throws Exception {
		paytmDetails.getDetails().forEach((k,v)-> parameters.put(k, v));
		parameters.put("MOBILE_NO","9876543210");
		parameters.put("EMAIL","test@gmail.com");
		parameters.put("ORDER_ID",pgutil.createOrderId());
		parameters.put("TXN_AMOUNT",transactionAmount);
		parameters.put("CUST_ID",pgutil.getCustomerId());
		String checkSum =  pgutil.getCheckSum(parameters,paytmDetails.getMerchantKey());
		parameters.put("CHECKSUMHASH",checkSum);
	}
	
	
	
	

	@Transactional
	@Override
	public String pgResponse(HttpServletRequest request) throws Exception {
		Map<String, String[]> mapData = request.getParameterMap();
		TreeMap<String,String> parameters = new TreeMap<String,String>();
		mapData.forEach((key,val)-> parameters.put(key, val[0]));
		String paytmChecksum =  "";
		if(mapData.containsKey("CHECKSUMHASH"))
		{
			paytmChecksum = mapData.get("CHECKSUMHASH")[0];
		}
		String result;
		
		boolean isValideChecksum = false;
		try{
			isValideChecksum = pgutil.validateCheckSum(parameters, paytmChecksum,paytmDetails.getMerchantKey());
			if(isValideChecksum && parameters.containsKey("RESPCODE")){
				if(parameters.get("RESPCODE").equals("01")){
					result =" <h1 style='color:green'>Payment Successful </h1>";
				}else{
					result="<h1 style='color:red'>Payment Failed.</h1>";
				}
			}else{
				result="<h1 style='color:red'>Checksum mismatched.</h1>";
			}
		}catch(Exception e){
			result=e.toString();
		}
		pgDao.updatePaymentDtls(pgutil.createEntity(parameters));
		return result;
		
	}
	

	@Override
	public String verifyTxn(String orderID)  {
		String transactionURL = "https://securegw-stage.paytm.in/merchant-status/getTxnStatus";
		TreeMap<String, String> paytmParams = new TreeMap<String, String>();
		paytmParams.put("MID", paytmDetails.getMerchantId());
		paytmParams.put("ORDERID", orderID);
		String responseData = "";
		 DataOutputStream requestWriter=null;
		 BufferedReader responseReader=null;
		try {
		    String paytmChecksum = CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(paytmDetails.getMerchantKey(), paytmParams);
		    paytmParams.put("CHECKSUMHASH", paytmChecksum);
		    JSONObject obj = new JSONObject(paytmParams);
		    String postData = "JsonData=" + obj.toString();
		    URL url = new URL(transactionURL);
		    Proxy proxy = new Proxy(Type.HTTP, new InetSocketAddress("proxy.cognizant.com", 6050));
		    HttpURLConnection connection = (HttpURLConnection) url.openConnection(proxy);
		    connection.setRequestMethod("POST");
		    connection.setRequestProperty("contentType", "application/json");
		    connection.setUseCaches(false);
		    connection.setDoOutput(true);
		    
		    requestWriter = new DataOutputStream(connection.getOutputStream());
		    requestWriter.writeBytes( postData);
		    InputStream is = connection.getInputStream();
		    responseReader = new BufferedReader(new InputStreamReader(is));
		    if((responseReader.readLine()) != null) {
		    	responseData=responseReader.readLine();
		    }
		} catch (Exception exception) {
		    exception.printStackTrace();
		}finally{
			try {
				requestWriter.close();
				responseReader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return responseData;
	}

}
